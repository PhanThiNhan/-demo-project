export default class MediaHandle{
    getPermissions(){
        // return new Promise((resolve,reject)=>{
        //     navigator.getUserMedia({video:true, audio:true})
        //     .then(stream=>{
        //         resolve(stream);
        //     })
        //     .catch(err=>{
        //         reject(err)
        //     })
        // })
    }
}