import idReducer from './idReducer';
export default  idReducer;